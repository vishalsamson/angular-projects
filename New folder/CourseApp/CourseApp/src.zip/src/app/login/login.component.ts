import { Component } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  isAdmin:boolean = false;
  isStudent:boolean = false;

  __userService:UserService;
  

  constructor(__userService:UserService){
    this.__userService = __userService;
  }

  login(user:User){
    if(user.role === "admin"){
      console.log("Admin Page");
      this.isAdmin = true;
      this.isStudent = false;
    }
    else if(user.role === "student"){
      console.log("Student Page");
      this.isAdmin = false;
      this.isStudent = true;
    }
  }
}
