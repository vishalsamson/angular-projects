import { Component } from '@angular/core';
import { Course } from '../course';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {

  // __courseService:CourseService;
  // allCourses:Course[] = [];

  // constructor(__courseService:CourseService){
  //   this.__courseService = __courseService;
  // }

  // addCourseDetails(courseName:string,category:string,duration:string,language:string,cost:string,rating:string){

  // }
}
